def getCodeMap(whichOne):
    
    import xlrd
    
    X=74
    
    # Open the workbook that has all of the long and 
    # short character values. Get data from the first 
    # worksheet.
    wb = xlrd.open_workbook('ECS101chars.xls')
    sh = wb.sheet_by_index(0)   

    # There are X values. Loop through and add them 
    # all to the dictionary map.
    Bin2Char = {}
    Char2Bin = {}
    for i in range(X):
        
        char = sh.cell(i,0).value
        binVal = sh.cell(i,1).value
 
        # Print out the character and binary value.
        print(char, " : ", binVal)
        
        # Add the binary value and character to the dictionary.
        Char2Bin[char] = binVal
        Bin2Char[binVal] = char

    if whichOne == 'bin2char': 
        return Bin2Char
    else: 
        return Char2Bin

