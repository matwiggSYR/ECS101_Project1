import makeDictionary
def Decode(txtFile):
    myTxtFile = open(txtFile)
    inputBin = myTxtFile.read()
    myKey = makeDictionary.getCodeMap('bin2char')
    binList = inputBin.split('.')
    inputBin = binList[1]
    print("bin:",inputBin)
    myDecode = ""
    for i in range(len(inputBin)):
        if inputBin[i:(i+7)] in myKey:
            myDecode = myDecode + myKey.get(inputBin[i: (i + 7)])
            i = i + 8
        elif inputBin[i:(i+5)] in myKey:
            myDecode = myDecode + str(myKey.get(inputBin[i: (i + 5)]))
            i = i + 7


    print("myDecode:",myDecode)


Decode("bin_output.txt")
